import './App.css';
import HookForm from './components/HookForm';
import newUser from './components/HookForm'

function App() {
  return (
    <div className="App">
      <HookForm></HookForm>
    </div>
  );
}

export default App;

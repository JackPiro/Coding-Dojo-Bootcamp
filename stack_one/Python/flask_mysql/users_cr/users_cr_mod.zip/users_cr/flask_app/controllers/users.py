# burgers.py
from flask_app import app
from flask import render_template,redirect,request,Flask
from models.user import User


@app.route('/')
def users():
    return render_template("results.html", users = User.get_all() )

@app.route('/create_user', methods= ["POST"])
def create_user():

    data = {
        'id' : request.form['id'],
        'fname' : request.form['fname'],
        'lname' : request.form['lname'],
        'email' : request.form['email']
    }

    User.save(data)
    return redirect('/create')

@app.route('/create')
def render_create():
    return render_template('create.html')
function logout(element) {
    element.innerText = "Logout"
}
function hideButton(element) {
    element.remove();
}

// function hide(element) {
//     element.remove();
// }
